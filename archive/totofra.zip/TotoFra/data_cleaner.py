class DataCleaner:

    def clean(self, matches):
        cleaned = []
        for m in matches:
            if not m["home"] or not m["away"]:
                continue
            cleaned.append(m)
        return cleaned
