import os
import json

class OutputWriter:

    def __init__(self):
        with open("config.json", "r") as f:
            cfg = json.load(f)
        self.folder = cfg["output_folder"]

        if not os.path.exists(self.folder):
            os.makedirs(self.folder)

    def save(self, date_str, data):
        path = os.path.join(self.folder, f"{date_str}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        print(f"[OUTPUT] Salvato in {path}")
