import pandas as pd
import numpy as np
from math import exp, factorial
from team_normalizer import TeamNormalizer

class PoissonModel:

    def __init__(self):
        self.norm = TeamNormalizer()

        df = pd.read_csv("data/serie_a_results.csv")

        # Normalizzazione totale
        df["home"] = df["home"].astype(str).str.strip().apply(self.norm.normalize)
        df["away"] = df["away"].astype(str).str.strip().apply(self.norm.normalize)

        print("\n[DEBUG] Squadre nel CSV dopo normalizzazione:")
        print(sorted(df["home"].unique()))

        self.avg_home_goals = df["home_goals"].mean()
        self.avg_away_goals = df["away_goals"].mean()

        self.attack_home = df.groupby("home")["home_goals"].mean() / self.avg_home_goals
        self.attack_away = df.groupby("away")["away_goals"].mean() / self.avg_away_goals

        self.defense_home = df.groupby("home")["away_goals"].mean() / self.avg_away_goals
        self.defense_away = df.groupby("away")["home_goals"].mean() / self.avg_home_goals

    def poisson(self, lam, k):
        return (lam ** k) * exp(-lam) / factorial(k)

    def predict_match(self, home, away):
        home_n = self.norm.normalize(home)
        away_n = self.norm.normalize(away)

        print(f"[DEBUG] Match: {home} vs {away} -> {home_n} vs {away_n}")

        lambda_home = (
            self.attack_home.get(home_n, 1) *
            self.defense_away.get(away_n, 1) *
            self.avg_home_goals
        )

        lambda_away = (
            self.attack_away.get(away_n, 1) *
            self.defense_home.get(home_n, 1) *
            self.avg_away_goals
        )

        print(f"[DEBUG] λ_home={lambda_home}, λ_away={lambda_away}")

        max_goals = 6
        matrix = np.zeros((max_goals+1, max_goals+1))

        for i in range(max_goals+1):
            for j in range(max_goals+1):
                matrix[i][j] = self.poisson(lambda_home, i) * self.poisson(lambda_away, j)

        p_home = np.sum(np.tril(matrix, -1))
        p_draw = np.sum(np.diag(matrix))
        p_away = np.sum(np.triu(matrix, 1))

        return {
            "home": home,
            "away": away,
            "p_home": float(p_home),
            "p_draw": float(p_draw),
            "p_away": float(p_away)
        }

    def predict(self, matches):
        results = []
        for m in matches:
            pred = self.predict_match(m["home"], m["away"])
            results.append(pred)
        return results
