import json
from tipster.tipster_predictz import PredictZTipster
from tipster.tipster_api_free import FootballDataOddsTipster

class TipsterLoader:

    def __init__(self):
        with open("config.json", "r") as f:
            cfg = json.load(f)

        api_key = cfg["football_data_api_key"]

        self.clients = [
            PredictZTipster(),
            FootballDataOddsTipster(api_key)
        ]

    def load_all(self, date_str):
        all_preds = []
        for client in self.clients:
            try:
                preds = client.get_predictions(date_str)
                all_preds.extend(preds)
            except Exception as e:
                print(f"[ERRORE TIPSTER] {client.__class__.__name__}: {e}")
        return all_preds
