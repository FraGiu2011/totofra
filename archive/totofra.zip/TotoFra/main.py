from data_fetcher import DataFetcher
from data_cleaner import DataCleaner
from modello_poisson import PoissonModel
from comparator import Comparator
from tipster_loader import TipsterLoader
from output_writer import OutputWriter

def main():
    MATCHDAY = 32   # <-- QUI scegli la giornata da analizzare

    fetcher = DataFetcher()
    cleaner = DataCleaner()
    model = PoissonModel()
    comparator = Comparator()
    tipsters = TipsterLoader()
    writer = OutputWriter()

    matches = fetcher.get_matches(MATCHDAY)
    matches = cleaner.clean(matches)
    model_preds = model.predict(matches)
    tipster_preds = tipsters.load_all(MATCHDAY)
    comparison = comparator.compare(model_preds, tipster_preds)

    writer.save(f"matchday_{MATCHDAY}", comparison)

if __name__ == "__main__":
    main()
