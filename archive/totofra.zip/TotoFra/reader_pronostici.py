import json

def load_output(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def main():
    data = load_output("output/matchday_32.json")

    print("\n=== TOTO FRA – PRONOSTICI DA JSON ===\n")

    for match in data:
        home = match["model"]["home"]
        away = match["model"]["away"]

        p_home = match["model"]["p_home"] * 100
        p_draw = match["model"]["p_draw"] * 100
        p_away = match["model"]["p_away"] * 100

        # Esito 1X2
        if p_home > p_draw and p_home > p_away:
            esito = "1"
        elif p_away > p_home and p_away > p_draw:
            esito = "2"
        else:
            esito = "X"

        print(f"{home} vs {away}")
        print(f"  1: {p_home:.1f}%   X: {p_draw:.1f}%   2: {p_away:.1f}%")
        print(f"  Esito modello: {esito}\n")

if __name__ == "__main__":
    main()
