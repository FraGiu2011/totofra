import requests
import json
import time

class DataFetcher:

    def __init__(self):
        with open("config.json", "r") as f:
            cfg = json.load(f)

        self.api_key = cfg["football_data_api_key"]
        self.competitions = cfg.get("competitions", [])
        self.headers = {"X-Auth-Token": self.api_key}

    def get_matches(self, matchday):
        all_matches = []

        for comp in self.competitions:
            print(f"[FETCHER] Carico partite per competizione: {comp}")
            matches = self._fetch_competition_matches(comp, matchday)
            all_matches.extend(matches)

        print(f"[FETCHER] Totale partite trovate: {len(all_matches)}")
        return all_matches

    def _fetch_competition_matches(self, comp_code, matchday):
        url = f"https://api.football-data.org/v4/competitions/{comp_code}/matches"
        params = {"matchday": matchday}

        for attempt in range(3):
            try:
                print(f"[FETCHER]   Tentativo {attempt+1}/3 per {comp_code}...")
                r = requests.get(url, headers=self.headers, params=params, timeout=30)
                r.raise_for_status()
                data = r.json()

                matches = []
                for m in data.get("matches", []):
                    matches.append({
                        "competition": comp_code,
                        "home": m["homeTeam"]["name"],
                        "away": m["awayTeam"]["name"],
                        "utcDate": m["utcDate"]
                    })

                print(f"[FETCHER]   {comp_code}: trovate {len(matches)} partite.")
                return matches

            except requests.exceptions.Timeout:
                print(f"[FETCHER]   Timeout per {comp_code}, riprovo...")
                time.sleep(2)

            except Exception as e:
                print(f"[FETCHER]   Errore su {comp_code}: {e}")
                return []

        print(f"[FETCHER]   Nessuna risposta da {comp_code}.")
        return []
