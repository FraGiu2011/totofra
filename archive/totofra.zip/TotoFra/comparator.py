# comparator.py

from team_normalizer import TeamNormalizer

class Comparator:
    def __init__(self):
        # Inizializza il normalizzatore dei nomi squadra
        self.norm = TeamNormalizer()

    def compare(self, model_preds, tipster_preds):
        """
        Confronta le previsioni del modello con quelle dei tipster.
        Restituisce una lista di match con:
        - probabilità modello
        - pronostici tipster (se trovati)
        """
        results = []

        for m in model_preds:
            match_result = {
                "match": f"{m['home']} - {m['away']}",
                "model": m,
                "tipsters": []
            }

            # Normalizza i nomi del modello
            model_home = self.norm.normalize(m["home"])
            model_away = self.norm.normalize(m["away"])

            for t in tipster_preds:
                # Normalizza i nomi del tipster
                tip_home = self.norm.normalize(t["home"])
                tip_away = self.norm.normalize(t["away"])

                # Confronto normalizzato
                if model_home == tip_home and model_away == tip_away:
                    match_result["tipsters"].append(t)

            results.append(match_result)

        return results
