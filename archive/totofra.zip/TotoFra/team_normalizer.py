import re

class TeamNormalizer:

    def __init__(self):
        # Mapping manuale esteso e definitivo
        self.manual_map = {
            "empoli fc": "empoli",
            "ssc napoli": "napoli",
            "us lecce": "lecce",
            "acf fiorentina": "fiorentina",
            "venezia fc": "venezia",
            "atalanta bc": "atalanta",
            "cagliari calcio": "cagliari",
            "torino fc": "torino",
            "as roma": "roma",
            "fc internazionale milano": "inter",
            "internazionale": "inter",
            "inter milano": "inter",
            "inter fc": "inter",

            # Premier League
            "wolverhampton wanderers fc": "wolves",
            "wolverhampton wanderers": "wolves",
            "manchester city fc": "manchester city",
            "manchester city": "manchester city",
            "liverpool fc": "liverpool",
            "chelsea fc": "chelsea",
        }

        # Parole da rimuovere
        self.remove_words = [
            "fc", "ssc", "us", "ac", "acf", "as", "bc", "calcio",
            "football", "club", "milano", "f.c", "s.c", "a.c"
        ]

    def normalize(self, name: str) -> str:
        if not name:
            return ""

        n = name.lower()
        n = re.sub(r"[^a-z0-9 ]", "", n)

        # mapping manuale
        if n in self.manual_map:
            return self.manual_map[n]

        parts = [p for p in n.split() if p not in self.remove_words]

        # fallback: prima parola
        return parts[0] if parts else n
