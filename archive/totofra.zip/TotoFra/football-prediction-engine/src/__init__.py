# Data loading module
