# Tipster comparison module
