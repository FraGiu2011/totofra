import schedule
import time
import json
from main import main

def start_scheduler():
    with open("config.json", "r") as f:
        cfg = json.load(f)

    run_time = cfg.get("scheduler_time", "08:00")

    schedule.every().day.at(run_time).do(main)

    print(f"[SCHEDULER] Avviato. Esecuzione giornaliera alle {run_time}")

    while True:
        schedule.run_pending()
        time.sleep(30)
